<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

require_once('credentials.php');
$dbname='testDB';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

echo array_key_exists('submit',$_POST);
if (array_key_exists( 'submit', $_POST)){
    $sql = "INSERT INTO MyGuests (firstname, lastname, email) 
    VALUES ('{$_POST['firstname']}', '{$_POST['lastname']}', '{$_POST['email']}')";
    // echo $sql;
    
    
    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?> 

<form action="db_table_start.php" method="post">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname">
    <br/>
    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname">
    <label for="email">Email Address</label>
    <input type="email" id="email" name="email">
    <input type="submit" name='submit'>
</form>



<?php
$conn->close();
?>