<?php
require_once('credentials.php');
$dbname = "testDB";

// Create connection
try{
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
    echo "Connection Failed to database". $conn->connect_error;
}
} catch(Exception $e){
    require_once('db_start.php');
    die("Restart the project");
}

$table_query = "CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($table_query) === TRUE) {
    echo "Table MyGuests created successfully";
  } else {
    echo "Error creating table: " . $conn->error;
  }
  

?>