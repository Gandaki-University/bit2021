<?php
require_once('credentials.php');
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

// status = ;
try{
    if ($conn->query("CREATE DATABASE testDB") === TRUE){
        echo "DB Created Successfully";
    } 
} catch(Exception $e){
        print("<br/>");
            // echo "DB Was present already". $conn->error;
            print_r( $conn);
}





?> 