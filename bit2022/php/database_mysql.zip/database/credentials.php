<?php 
$servername = "localhost";
$username = "anupadkh";
$password = "gandakiUniversity";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
?>